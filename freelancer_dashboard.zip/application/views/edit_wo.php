<div class="container-fluid cont">
  <h1 class="mt-4">Edit Work Order</h1>
  <?php
    foreach($det_wo as $detail_wo){
    $id_wo = $_GET['id_wo'];

  ?>
  <div class="shadow-sm mb-5 p-3 bg-white rounded box-data">
    <form action="<?=base_url()?>data/edit_wo_act" method="post">
    <input type="hidden" class="form-control" name="id_data" value="<?=$id_wo?>">
      <div class="row g-3">
        <h6>WO Information</h6>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Wo Number</label>
          <input type="text" class="form-control" name="wo_number" value="<?=$detail_wo->wo_number?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Case ID</label>
          <input type="text" class="form-control" name="case_id" value="<?=$detail_wo->case_id?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Asset Serial</label>
          <input type="text" class="form-control" name="asset_serial" value="<?=$detail_wo->asset_serial?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">WO Description</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="wo_desc" required><?=$detail_wo->wo_desc?></textarea>
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Product Description</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="prod_desc" required><?=$detail_wo->product_desc?></textarea>
        </div>
        <h6>Account Information</h6>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Company Name</label>
          <input type="text" class="form-control" name="company_name" value="<?=$detail_wo->company_name?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Customer Name</label>
          <input type="text" class="form-control" name="customer_name" value="<?=$detail_wo->contact_name?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Contact Phone</label>
          <input type="text" class="form-control" name="contact_phone" value="<?=$detail_wo->contact_phone?>">
        </div>
        <div class="col-md-4">
          <label for="inputState" class="form-label">City</label>
          <select class="form-select" name="city">
              <?php foreach($kota as $kota1) { ?>
                <option value="<?=$kota1->kb_id?>" <?php if($detail_wo->city=$kota1->kb_id) {echo "selected";}?>><?=$kota1->kb_kab_kot?> </option> 
              <?php } ?> 
          </select>
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Address</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="address" required><?=$detail_wo->address?></textarea>
        </div>
        <h6>Date</h6>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Request Date</label>
          <input type="date" class="form-control" name="request_date" value="<?=$detail_wo->requested_date?>">
          <p id="requested_date"></p>
        </div>
        <h6>Order Information</h6>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Part Number</label>
          <input type="text" class="form-control" name="part_number" value="<?=$detail_wo->part_number?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">IGSO Number</label>
          <input type="text" class="form-control" name="igso_number" value="<?=$detail_wo->igso_number?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Part Description</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="part_desc" required><?=$detail_wo->part_desc?></textarea>
        </div>

        <h6>Others Information</h6>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Visit</label>
          <input type="text" class="form-control" name="visit" value="<?=$detail_wo->visit?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Link HP SubK Partner</label>
          <input type="text" class="form-control" name="link" value="<?=$detail_wo->link?>">
        </div>
        <div class="col-md-4">
          <label for="inputAddress" class="form-label">Comment</label>
          <input type="text" class="form-control" name="comment" value="<?=$detail_wo->comment?>">
        </div>
        <div class="col-md-12 d-flex justify-content-center">
          <hr class="update-wo">
        </div>
        <div class="col-md-12 d-flex justify-content-center btn-update-wo">
          <button type="button" class="btn btn-default" onclick="javascript:history.back()">Cancel</button>
          <button type="submit" class="btn btn-success">Update</button>
        </div>
      </div>
    </form>
  </div>
  </div>
  <?php
  }
  ?>
</div>